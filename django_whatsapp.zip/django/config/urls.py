"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

    # from tweet import views
from django.contrib.auth import views as auth_views
# from restrorance import views as restrorance_views
# from rth import views as rth_views
# from whatsapp import views as whatsapp_views
from anime import views as anime_views
urlpatterns = [
    path('admin/', admin.site.urls),
    # path('', rth_views.sing, name='sing'),
    # path('rth/', include('rth.urls')),
    # path('', views.index, name='index'),
    # path('tweet/', include('tweet.urls')),
    # path('', restrorance_views.home_page, name='home_page'),
    # path('restrorance/', include('restrorance.urls')),
    # path('',whatsapp_views.index, name='index'),
    # path('whatsapp/', include('whatsapp.urls')),
    path('', anime_views.index, name='index'),
    path('anime/', include('anime.urls')),
    # path('account/', include('django.contrib.auth.urls')),
    path('admin/', admin.site.urls),



] 
# + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
# if settings.DEBUG:
#     urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
#     urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)